package com.example.dana.austinbucketlist;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ItemInfoActivity extends AppCompatActivity {

    //variables
    String activityTitle;
    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_info);

        //initialize database
        myDb = new DatabaseHelper(this);

        //pull title from intent
        activityTitle = getIntent().getStringExtra("listItem");
        final TextView title = (TextView) findViewById(R.id.title);
        title.setText(activityTitle);

        //populate textViews with database data
        populateTextViews();

        //set title font
        Typeface tf = Typeface.createFromAsset(ItemInfoActivity.this.getResources().getAssets(), "fonts/hansolo.ttf");
        title.setTypeface(tf);
    }

    public void populateTextViews(){
        //final text view variables
        final TextView date = (TextView) findViewById(R.id.date);
        final TextView rating = (TextView) findViewById(R.id.rating);
        final TextView comment = (TextView) findViewById(R.id.comment);

        //pull values from database
        Cursor res = myDb.getRowData("'"+activityTitle+"'");
        if (res.getCount() == 0) {
            Toast.makeText(ItemInfoActivity.this, "Nothing found", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            if(res.isNull(2)){
                buffer.append(" ,");}
            else{
            buffer.append(res.getString(2)+",");}
            if(res.isNull(3)){
                buffer.append("- ,");}
            else{
                buffer.append(res.getString(3)+",");}
            if(res.isNull(4)){
                buffer.append(" ,");}
            else{
                buffer.append(res.getString(4)+",");}
        }

        //set text views
        String data = buffer.toString();
        String[] dataArray = data.split(",");
        date.setText(dataArray[0]);
        rating.setText(dataArray[1]+"/5");
        comment.setText(dataArray[2]);

        //get image and put into imageview
        Cursor res2 = myDb.getImagePath("'"+activityTitle+"'");
        if (res.getCount() != 0) {
            StringBuffer buffer2 = new StringBuffer();
            while (res2.moveToNext()) {
                buffer2.append(res2.getString(0));
            }
            String path = buffer2.toString();
            loadImage(path, activityTitle.replace(" ","_"));
        }
    }

    //pull image from external storage
    private void loadImage(String path, String name)
    {
        try {
            File f=new File(path, name+".jpg");
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            ImageView img=(ImageView)findViewById(R.id.imageView2);
            img.setImageBitmap(b);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    //on edit icon click, take to edit info page
    public void onEditItemClick(View v){
        Intent i = new Intent(ItemInfoActivity.this, AddItemInfoActivity.class);
        i.putExtra("listItem", activityTitle);
        startActivity(i);
    }
}