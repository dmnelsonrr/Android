package com.example.dana.austinbucketlist;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class AddItemInfoActivity extends AppCompatActivity {

    //variables
    DatabaseHelper myDb;
    EditText editDate;
    EditText editComment;
    Spinner spinner;
    String itemName;
    String path;
    private static final int SELECT_PICTURE = 0;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item_info);

        //widget ids
        editDate = (EditText)findViewById(R.id.editDate);
        editComment = (EditText)findViewById(R.id.editComment);
        spinner = (Spinner)findViewById(R.id.editRating);
        imageView = (ImageView) findViewById(R.id.cameraImage);

        //create database
        myDb = new DatabaseHelper(this);

        //change title textView from intent
        itemName = getIntent().getStringExtra("listItem");
        final TextView title = (TextView) findViewById(R.id.infoTitle);
        title.setText("Update " + itemName);

        //set title font
        Typeface tf = Typeface.createFromAsset(AddItemInfoActivity.this.getResources().getAssets(), "fonts/hansolo.ttf");
        title.setTypeface(tf);

        //create adapter and populate spinner
        List<Integer> rating = new ArrayList<>();
        rating.add(1);
        rating.add(2);
        rating.add(3);
        rating.add(4);
        rating.add(5);
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, rating);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        //populate edit views based on current data
        populateEditViews();
    }

    public void populateEditViews(){
        //pull current data from database
        Cursor res = myDb.getRowData("'" + itemName + "'");
        if (res.getCount() == 0) {
            Toast.makeText(AddItemInfoActivity.this, "Nothing found", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            if(res.isNull(2)){
                buffer.append(" ,");}
            else{
                buffer.append(res.getString(2)+",");}
            if(res.isNull(4)){
                buffer.append(" ,");}
            else{
                buffer.append(res.getString(4)+",");}

            //set spinner selection
            if(res.isNull(3)){
                break;}
            else{
                int pos = res.getInt(3);
                spinner.setSelection(pos-1);}
        }

        //set editviews based on database info
        String data = buffer.toString();
        String[] dataArray = data.split(",");
        editDate.setText(dataArray[0]);
        editComment.setText(dataArray[1]);
    }

    //on update button click
    public void onButtonClick(View v){
        //populate database with user input
        updateData();

        //open bucketlist activity
        Intent i = new Intent(AddItemInfoActivity.this, MyBucketlistActivity.class);
        startActivity(i);
    }

    public void updateData(){
        //get item ID
        Cursor res = myDb.getRowData("'"+itemName+"'");
        if (res.getCount() == 0) {
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append(res.getString(0));
        }
        String id = buffer.toString();

        //upload photo to external storage
        path = null;
        if (imageView.getDrawable() != null){
            Bitmap bitmap = ((BitmapDrawable)imageView.getDrawable()).getBitmap();
            path = saveImage(bitmap, itemName.replace(" ", "_"));
        }

        //update data in database
        boolean isInserted = myDb.updateData(id, itemName, editDate.getText().toString(),
                spinner.getSelectedItem().toString(), editComment.getText().toString(), path);
        if (isInserted == true)
            Toast.makeText(AddItemInfoActivity.this, "Information updated", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(AddItemInfoActivity.this, "ERROR: Information not updated", Toast.LENGTH_LONG).show();
    }

    //save image to external storage
    private String saveImage(Bitmap bitmapImage, String name) {
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        // path to /data/data/yourapp/app_data/austin_bucketlist
        File directory = cw.getDir("austin_bucketlist", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath=new File(directory, name+".jpg");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return directory.getAbsolutePath();
    }

    //open phone's photo gallery
    public void onAddPhotoClick(View v){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,
                "Select Picture"), SELECT_PICTURE);
    }

    //get intent result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK) {
            Bitmap bitmap = getPath(data.getData());
            imageView.setImageBitmap(bitmap);
        }
    }

    //get image bitmap
    private Bitmap getPath(Uri uri) {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor
                .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String filePath = cursor.getString(column_index);
        cursor.close();
        // Convert file path into bitmap image using below line.
        Bitmap bitmap = BitmapFactory.decodeFile(filePath);
        return bitmap;
    }
}