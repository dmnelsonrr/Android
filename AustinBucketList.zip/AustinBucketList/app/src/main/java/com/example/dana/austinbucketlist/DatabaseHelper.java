package com.example.dana.austinbucketlist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper{

    //declare database, table, and columns
    public static final String DATABASE_NAME = "bucketlist.db";
    public static final String TABLE_NAME = "bucketlist_items";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "ITEM_NAME";
    public static final String COL_3 = "DATE";
    public static final String COL_4 = "RATING";
    public static final String COL_5 = "COMMENT";
    public static final String COL_6 = "IMG_PATH";

    //reference to java class
    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        //create table
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, ITEM_NAME TEXT UNIQUE, " +
                "DATE TEXT, RATING TEXT, COMMENT TEXT, IMG_PATH TEXT)");

        //populate database
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('SXSW')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Pecan Street Festival')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Kite Festival')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Austin City Limits')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('360 Bridge')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('See the Congress Bridge bats')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Mount Bonnell')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Barton Springs')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Zilker Park')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('6th Street')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Graffiti Park')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('South Congress')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Franklins BBQ')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Kayak on Town Lake')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Trail of Lights')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('LBJ Wildflower Center')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Eeyores Birthday')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Texas State Capitol building')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Bob Bullock Museum')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Hamilton Pool')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('Harry Ransom Center')");
        db.execSQL("insert into bucketlist_items (ITEM_NAME) values ('UT football game')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        // upgrade the table if version number is increased and call onCreate to create a new DB
        db.execSQL("DROP TABLE IF EXISTS" + TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(String itemName, String date, String rating, String comment, String path) {

        // Open the database for reading and writing
        SQLiteDatabase db = this.getWritableDatabase();

        // This class is used to store a set of values that a ContentResolver can process.
        ContentValues contentValues = new ContentValues();

        // you need to specify the column and the data for that column
        contentValues.put(COL_2, itemName);
        contentValues.put(COL_3, date);
        contentValues.put(COL_4, rating);
        contentValues.put(COL_5, comment);
        contentValues.put(COL_6, path);

        // need to give this the table name and the content values
        long result = db.insert(TABLE_NAME, null, contentValues);

        // method will return -1 if the insert did not work
        if (result == -1)
            return false;
        else
            return true;
    }

    //return all columns (except image) of row
    public Cursor getRowData(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select ID, ITEM_NAME, DATE, RATING, COMMENT from " + TABLE_NAME + " where ITEM_NAME = " + itemName, null);
        return res;
    }

    //return image path
    public Cursor getImagePath(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select IMG_PATH from " + TABLE_NAME + " where ITEM_NAME = " + itemName, null);
        return res;
    }

    public boolean updateData(String id, String itemName, String date, String rating, String comment, String path){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, id);
        contentValues.put(COL_2, itemName);
        contentValues.put(COL_3, date);
        contentValues.put(COL_4, rating);
        contentValues.put(COL_5, comment);
        contentValues.put(COL_6, path);
        db.update(TABLE_NAME, contentValues, "id = ?", new String[]{id});
        return true;
    }

    public Integer deleteData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "id = ?", new String[] {id});
    }

    //get all item_names
    public Cursor getTasks(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select ITEM_NAME from " + TABLE_NAME, null);
        return res;
    }
}