package com.example.dana.austinbucketlist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MyBucketlistActivity extends AppCompatActivity {

    //variables
    DatabaseHelper myDb;
    String newItem;
    ListView listView;
    TextView textView;
    View rowView;
    float historicX = Float.NaN, historicY = Float.NaN;
    static final int DELTA = 50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_bucketlist);

        //initialize database
        //this.deleteDatabase("bucketlist.db");
        myDb = new DatabaseHelper(this);

        //populate ListView
        refreshListView();

        //set title font
        TextView titleTextView = (TextView) findViewById(R.id.textView2);
        Typeface tf = Typeface.createFromAsset(MyBucketlistActivity.this.getResources().getAssets(), "fonts/hansolo.ttf");
        titleTextView.setTypeface(tf);
    }

    //refreshes ListView
    public void refreshListView() {
        //shows all task names
        textView = (TextView) findViewById(R.id.textViewTask);
        String[] myStringArray = getTaskArray();
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, R.layout.task_layout, R.id.textViewTask, myStringArray);
        listView = (ListView) findViewById(R.id.listView2);
        listView.setAdapter(adapter);

        //swipe to delete
        listView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        historicX = event.getX();
                        historicY = event.getY();
                        break;

                    //if swipe left
                    case MotionEvent.ACTION_UP:
                        if (event.getX() - historicX < -DELTA) {

                            //find row that was swiped
                            Rect rect = new Rect();
                            int childCount = listView.getChildCount();
                            int[] listViewCoords = new int[2];
                            listView.getLocationOnScreen(listViewCoords);
                            int x = (int) event.getRawX() - listViewCoords[0];
                            int y = (int) event.getRawY() - listViewCoords[1];
                            View child;
                            for (int i = 0; i < childCount; i++) {
                                child = listView.getChildAt(i);
                                child.getHitRect(rect);
                                if (rect.contains(x, y)) {
                                    rowView = child; // This is your down view
                                    break;
                                }
                            }

                            //get text from row and call deleteRow
                            if (rowView != null) {
                                CharSequence text = ((TextView) rowView.findViewById(R.id.textViewTask)).getText();
                                deleteRow(text);
                            }
                            return true;
                        } else if (event.getX() - historicX > DELTA) {
                            return true;
                        }
                        break;
                    default:
                        return false;
                }
                return true;
            }
        });
    }

    //delete row from database
    public void deleteRow(CharSequence item){
        //set buttons for alert box
        final CharSequence item2 = item;
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){

                    //if clicks yes
                    case DialogInterface.BUTTON_POSITIVE:

                        //get item ID
                        Cursor res = myDb.getRowData("'"+item2+"'");
                        if (res.getCount() == 0) {
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append(res.getString(0));
                        }
                        String id = buffer.toString();

                        //delete row
                        myDb.deleteData(id);

                        //refresh UI
                        refreshListView();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        break;
                }
            }
        };

        //show alert box
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to delete '"+item2+"' from your bucketlist?").setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();
    }

    //returns array of tasks for ListView
    public String[] getTaskArray(){
        //return empty array if empty database
        String[] emptyTaskArray = {};
        Cursor res = myDb.getTasks();
        if (res.getCount() == 0) {
            return emptyTaskArray;
        }

        //return array of tasks
        List<String> taskList = new ArrayList<>();
        while (res.moveToNext()) {
            StringBuffer buffer = new StringBuffer();
            buffer.append(res.getString(0));
            taskList.add(buffer.toString());
        }
        String[] taskArray = new String[taskList.size()];
        taskArray = taskList.toArray(taskArray);
        return taskArray;
    }

    //open item info activity when list item is clicked
    public void onItemClick(View v){
        TextView textView = (TextView)v;
        CharSequence itemName = textView.getText();
        Intent i = new Intent(MyBucketlistActivity.this, ItemInfoActivity.class);
        i.putExtra("listItem", itemName);
        startActivity(i);
    }

    //add new task
    public void onAddButtonClick(View v){
        //build alert to add new item
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Bucketlist Item");

        // Set up user input
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //get user input
                newItem = input.getText().toString();
                //if empty, display error
                if(newItem==""){
                    Toast.makeText(MyBucketlistActivity.this, "Please enter bucketlist item title", Toast.LENGTH_LONG).show();
                }
                if(newItem.contains("'")){
                    Toast.makeText(MyBucketlistActivity.this, "The symbol ' is not supported", Toast.LENGTH_LONG).show();
                }
                //if not, add to database
                else {
                    myDb.insertData(newItem, null, null, null, null);
                    refreshListView();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }
}